package ecommerce.business;

import jakarta.persistence.*;

@Entity
@Table(name = "inventory", schema = "ecommerce")
public class InventoryEntity {

    @Id
    @JoinColumn(name = "PRODUCTID")
    private Long productid;
    @Basic
    @Column(name = "AMOUNT")
    private Integer amount;

//    public void setProduct(ProductEntity product) {
//        this.product = product;
//    }
//
//    public ProductEntity getProduct() {
//        return product;
//    }

    public void setProduct(Long productid) {
        this.productid = productid;
    }

    public Long getProduct() {
        return productid;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        InventoryEntity that = (InventoryEntity) o;


        if (amount != null ? !amount.equals(that.amount) : that.amount != null) return false;
        if (productid != null ? !productid.equals(that.productid) : that.productid != null) return false;

        return true;
    }
}
