//Mục yêu của Servlet này:
// + Load thông tin từ database lên trang JSP khi người dùng UPDATE/INSERT thông tin sản phẩm

package ecommerce.controller;

import ecommerce.business.CustomerEntity;
import ecommerce.business.InventoryEntity;
import ecommerce.business.ProductEntity;
import ecommerce.business.ShopEntity;
import ecommerce.data.CustomerDB;
import ecommerce.data.InventoryDB;
import ecommerce.data.ProductDB;
import ecommerce.data.ShopDB;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "EditProductServlet")
public class EditProductServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException{
        String url = "/productEdit.jsp";
        HttpSession session = request.getSession();

        String action = request.getParameter("action");
        String id = request.getParameter("Id");

        if(action.equals(Constants.ACTION_INSERT)){
            session.setAttribute("action", Constants.ACTION_INSERT);
        }

        if(action.equals(Constants.ACTION_EDIT)){
            session.setAttribute("action", Constants.ACTION_EDIT);
            session.setAttribute("Id", id);

            ProductEntity product = ProductDB.getProductById(Long.parseLong(id));
            request.setAttribute("product", product);

            InventoryEntity existInvent = InventoryDB.getInventoryById(Long.parseLong(id));
            request.setAttribute("inventory", existInvent);
        }

        if(action.equals(Constants.ACTION_DELETE)){
            session.setAttribute("action", Constants.ACTION_DELETE);
        }

        // load data from database to JSP file
//        CustomerEntity customer = CustomerDB.loginedCustomer;
//        request.setAttribute("user", customer);
//
//        ShopEntity shop = ShopDB.getShopByManagerID(customer.getCustomerid());
//        request.setAttribute("shop", shop);

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
