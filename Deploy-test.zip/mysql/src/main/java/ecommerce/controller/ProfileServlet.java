package ecommerce.controller;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import ecommerce.business.CustomerEntity;
import ecommerce.business.ProductEntity;
import ecommerce.business.ShopEntity;
import ecommerce.data.CustomerDB;
import ecommerce.data.ProductDB;
import ecommerce.data.ShopDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "ProfileServlet")
public class ProfileServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        String url = "/userProfile.jsp";
        HttpSession session = request.getSession();

        String action = request.getParameter("action");

        // data
        CustomerEntity customer = CustomerDB.loginedCustomer;
        ShopEntity shop = ShopDB.getShopByManagerID(customer.getCustomerid());

        if(action != null){
            request.setAttribute("shop", shop);

            if(action.equals("userProfile")){
                request.setAttribute("user", customer);

                url = "/userProfile.jsp";
            }else if (action.equals("shopProfile")){
                // shop manager là người dùng đang login
                // truyền id là 1 chuỗi
                session.setAttribute("managerId",
                        Long.toString(customer.getCustomerid()));

                session.setAttribute("listProduct",
                        ProductDB.getProductsByShopID(shop.getShopid()));
//                request.setAttribute("listProduct",
//                        ProductDB.getProductsByShopID(shop.getShopid()));
                url = "/shopProfile.jsp";
            }
        }

        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
