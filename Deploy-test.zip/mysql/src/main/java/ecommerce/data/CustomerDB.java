package ecommerce.data;

import ecommerce.business.CustomerEntity;
import ecommerce.business.ProductEntity;
import ecommerce.business.ShopEntity;
import ecommerce.util.DBUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

public class CustomerDB {
    public static boolean isLogin = false;
    public static boolean isRemember = false;
    public static CustomerEntity loginedCustomer;

    public static void insert(CustomerEntity customer) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.persist(customer);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
    }

    public static void update(CustomerEntity customer) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(customer);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
    }

    public static void delete(CustomerEntity customer) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.remove(em.merge(customer));
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
    }
    //init
    public static CustomerEntity getCustomerById(Long cusId) {
        EntityManager em = DBUtil.getEntityManager();
        CustomerEntity customer = null;
        try {
            customer = em.find(CustomerEntity.class, cusId);
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            em.close();
        }
        return customer;
    }

    public static boolean checkLogin(String uName, String pass){
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT c FROM CustomerEntity c WHERE c.username = '" + uName +"' AND c.password = '" + pass + "'";
        TypedQuery<CustomerEntity> q = em.createQuery(qString, CustomerEntity.class);
        try {
            if(q.getSingleResult() != null){
                isLogin = true;
                return true;
            }
            else{
                isLogin = false;
                return false;
            }
        } catch (NoResultException e) {
            return false;
        } finally {
            em.close();
        }
    }

    public static CustomerEntity getCustomerByUserName(String uName) {
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT c FROM CustomerEntity c WHERE c.username = '" + uName + "'";
        TypedQuery<CustomerEntity> q = em.createQuery(qString, CustomerEntity.class);
        try {
            return q.getSingleResult();
        } catch (Exception e) {
            System.out.println(e);
            return null;
        } finally {
            em.close();
        }
    }

}
