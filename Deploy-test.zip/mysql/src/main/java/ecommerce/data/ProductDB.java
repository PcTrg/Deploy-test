package ecommerce.data;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import ecommerce.business.CategoryEntity;
import ecommerce.business.ProductEntity;
import ecommerce.business.ShopEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

import ecommerce.util.*;

public class ProductDB {
	
    public static void insert(ProductEntity product) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();        
        try {
            em.persist(product);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
    }

    public static void update(ProductEntity product) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(product);
            trans.commit();
        } catch (Exception e) {
            System.out.println("ProductDB.update() lỗi: " +e);
            trans.rollback();
        } finally {
            em.close();
        }
    }

    public static void delete(ProductEntity product) {
        EntityManager em = DBUtil.getEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();        
        try {
            em.remove(em.merge(product));
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }       
    }

    //Select all items of product
    public static List<ProductEntity> selectProduct() {
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }
    public static ProductEntity getProductById(Long id) {
        EntityManager em = DBUtil.getEntityManager();
        try {
            return em.find(ProductEntity.class, id);
        } finally {
            em.close();
        }
    }
    public static List<ProductEntity> selectProductASC(){
    	EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p ORDER BY p.productprice ASC";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }
    public static List<ProductEntity> selectProductDESC(){
    	EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p ORDER BY p.productprice DESC";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }   
    public static List<ProductEntity> getProductPopularity(){
    	EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p "
        		+ "ORDER BY p.producttotalselling DESC, "
        		+ "p.productavgrating DESC";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }
    
    //Get all Products from Location
    public static List<ProductEntity> getProductsAt(String location) {
        List<ShopEntity> shops = ShopDB.getShopsByLocation(location);
        List<ProductEntity> allProducts = new ArrayList<>();
        assert shops != null;
        for (ShopEntity shop : shops) {
            List<ProductEntity> products = ShopDB.getProductsByShop(shop.getShopid());
            assert products != null;
            allProducts.addAll(products);
        }
        return allProducts;
    }
    public static List<ProductEntity> getBestSellingProducts(){
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p "
                + "ORDER BY p.producttotalselling DESC";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }
    public static List<ProductEntity> getNewestProducts(){
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p "
                + "ORDER BY p.updatedate DESC";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }
    public static List<ProductEntity> getProductsRating(int rating){
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p "
                + "WHERE p.productavgrating = :rating";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        q.setParameter("rating", rating);
        try {
            return q.getResultList();
        } catch (NoResultException e) {        	
            return null;
        } finally {
            em.close();
        }
    }    
    public static long getTotalProducts() {
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT COUNT(p.productid) FROM ProductEntity p";
        TypedQuery<Long> q = em.createQuery(qString, Long.class);        
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {        	
            return 0;
        } finally {
            em.close();
        }
    }

    public static CategoryEntity getCategoryByName(String cateName) {
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT c FROM CategoryEntity c "
                + "WHERE c.name = '" + cateName + "'";
        TypedQuery<CategoryEntity> q = em.createQuery(qString, CategoryEntity.class);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    public static List<ProductEntity> getProductsByShopID(long shopID) {
        EntityManager em = DBUtil.getEntityManager();
        String qString = "SELECT p FROM ProductEntity p"
                + " WHERE p.shop = '" + shopID + "'";
        TypedQuery<ProductEntity> q = em.createQuery(qString, ProductEntity.class);
        try {
            return q.getResultList();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
}