package ecommerce.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DBUtil {
    private static EntityManagerFactory entityManagerFactory;
    public static EntityManager getEntityManager(){
        if (entityManagerFactory == null || !entityManagerFactory.isOpen()){
            entityManagerFactory = Persistence.createEntityManagerFactory("ecommerce");
        }
        return  entityManagerFactory.createEntityManager();
    }
}